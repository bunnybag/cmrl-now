var classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result =
[
    [ "Nearby_Search_Result", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result.html#a6b26f6fd95ef8e142e176f6e15124fa9", null ],
    [ "getDistance_from_current", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result.html#a87c9e05796132f5277fd511b0c82b07e", null ],
    [ "getStation_Name", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result.html#a72e081537dc4db1755258d092340e1fb", null ],
    [ "setDistance_from_current", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result.html#afed409953fb08c067f094e4b7830d7b1", null ],
    [ "setStation_Name", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___result.html#a0db37ed974641133d7430c296d421402", null ]
];