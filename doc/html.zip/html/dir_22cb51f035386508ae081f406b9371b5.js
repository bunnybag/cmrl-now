var dir_22cb51f035386508ae081f406b9371b5 =
[
    [ "BuildConfig.java", "_build_config_8java.html", [
      [ "BuildConfig", "classcom_1_1bunnybags_1_1cmrlnow_1_1_build_config.html", null ]
    ] ],
    [ "R.java", "_r_8java.html", [
      [ "R", "classcom_1_1bunnybags_1_1cmrlnow_1_1_r.html", null ]
    ] ]
];