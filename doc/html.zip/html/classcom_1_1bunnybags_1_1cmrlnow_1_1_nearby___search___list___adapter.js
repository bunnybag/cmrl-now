var classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___list___adapter =
[
    [ "Nearby_Search_List_Adapter", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___list___adapter.html#a9c11357b3c0e793adc8d4bdbf58f1ce7", null ],
    [ "getView", "classcom_1_1bunnybags_1_1cmrlnow_1_1_nearby___search___list___adapter.html#ab3d742a67ec7222f5422d381045fb159", null ]
];